#include "kalkulator.h"
#include <iostream>
#include <bitset>
#include <sstream>

using namespace std;

Kalkulator::Kalkulator() : mem(0.0), mem_used(false) {}

double Kalkulator::add(double a, double b) {
    mem = a + b;
    mem_used = true;
    return mem;
}

double Kalkulator::sub(double a, double b) {
    mem = a - b;
    mem_used = true;
    return mem;
}

double Kalkulator::mul(double a, double b) {
    mem = a * b;
    mem_used = true;
    return mem;
}

double Kalkulator::div(double a, double b) {
    // if (b == 0) {
    //     cerr << "Blad: Dzielenie przez zero!" << endl;
    //     return mem;
    // }
    mem = a / b;
    mem_used = true;
    return mem;
}

double Kalkulator::mod(double a, double b) {
    // if (b == 0) {
    //     cerr << "Blad: Dzielenie przez zero!" << endl;
    //     return mem;
    // }
    mem = a - (int)(a / b) * b;
    mem_used = true;
    return mem;
}

double Kalkulator::getMem() const {
    return mem;
}

void Kalkulator::setMem(double new_mem) {
    mem = new_mem;
    mem_used = true;
}

void Kalkulator::erase() {
    mem = 0.0;
    mem_used = false;
}

bool Kalkulator::isMemUsed() const {
    return mem_used;
}

// binarny
std::string Kalkulator::toBinary(int number) {
    if (number == 0) return "0";
    if (number < 0) return "-" + toBinary(-number);
    return std::bitset<32>(number).to_string().substr(std::bitset<32>(number).to_string().find('1'));
}

// ósemkowy
std::string Kalkulator::toOctal(int number) {
    std::ostringstream oss;
    oss << std::oct << number;
    return oss.str();
}

// szesnastkowy
std::string Kalkulator::toHex(int number) {
    std::ostringstream oss;
    oss << std::hex << std::uppercase << number;
    return oss.str();
}
