#pragma once
#include <string>

class Kalkulator {
private:
    double mem;
    bool mem_used;

public:
    Kalkulator();
    double add(double a, double b);
    double sub(double a, double b);
    double mul(double a, double b);
    double div(double a, double b);
    double mod(double a, double b);

    double getMem() const;
    void setMem(double new_mem);
    void erase();
    bool isMemUsed() const;

    std::string toBinary(int number);
    std::string toOctal(int number);
    std::string toHex(int number);
};
