Dokumentacja:  
Projekt kalkulatora napisałam w języku C++ przy użyciu Qt. Kalkulator obsługuje podstawowe operacje matematyczne, konwersję liczb pomiędzy systemami liczbowymi (binarny, ósemkowy, szesnastkowy), operacje pamięciowe oraz błędy związane z dzieleniem przez zero.

Struktura projektu:  
Pisząc projekt w visual studio podzieliłam go na:  
\-  kalkulator.h \- Definicja klasy \`Kalkulator\`, która implementuje operacje matematyczne i zarządza pamięcią.  
\- kalkulator.cpp \- Implementacja metod klasy \`Kalkulator\`, w tym operacje dodawania, odejmowania, mnożenia, dzielenia, modulo oraz konwersje liczb.  
\- projekt.cpp \- Główna funkcja, która uruchamia aplikację.

Operacje mateamtyczne

* add – Dodawanie dwóch liczb.  
* sub – Odejmowanie dwóch liczb.  
* mul – Mnożenie dwóch liczb.  
* div – Dzielenie dwóch liczb (błąd przy dzieleniu przez zero).  
* mod – Operacja modulo (błąd przy dzieleniu przez zero).

Operacje pamięciowe:

* getMem – Zwraca aktualną wartość w pamięci.  
* setMem – Ustawia nową wartość w pamięci.  
* erase – Czyści pamięć.  
* isMemUsed – Sprawdza, czy pamięć jest używana.

Konwersja systemów liczbowych:

* toBinary – Zwraca liczbę w systemie binarnym.  
* toOctal– Zwraca liczbę w systemie ósemkowym.  
* toHex– Zwraca liczbę w systemie szesnastkowym.

Dodatkowo:

* backspace \- Usuwa jeden znak.  
* AC \- Usuwa wszystkie znaki wraz z pamięcią.  
* ESC \- Przycisk wyjścia.  
* . \[przecinek\] \- Wstawia jeden przecinek w jednej liczbie.

Interfejs użytkownika  
Aplikacja jest zbudowana w Qt, z następującymi funkcjami:

* Okno aplikacji o stałym rozmiarze.  
* Przyciski do cyfr, operacji matematycznych oraz konwersji systemów liczbowych.  
* Przyciski operacji pamięciowych (set, get, erase \- M+, MR, MC).  
* Menu z opcją wyświetlania informacji o autorze.  
* Komunikaty błędów (np. dzielenie przez zero).

