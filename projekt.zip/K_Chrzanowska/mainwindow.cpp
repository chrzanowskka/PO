#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include <QMessageBox>
Kalkulator kalk;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionOAutorze_triggered()
{
    QMessageBox::information(this, "O autorze", "Klaudia Chrzanowska");
}

void MainWindow::on_jeden_clicked()
{
    if (wynikObliczony) {
        ui->lineEdit->clear();
        wynikObliczony = false;
    }
    ui->lineEdit->setText(ui->lineEdit->text() + "1");
}

void MainWindow::on_dwa_clicked()
{
    if (wynikObliczony) {
        ui->lineEdit->clear();
        wynikObliczony = false;
    }
    ui->lineEdit->setText(ui->lineEdit->text() + "2");
}

void MainWindow::on_trzy_clicked()
{
    if (wynikObliczony) {
        ui->lineEdit->clear();
        wynikObliczony = false;
    }
    ui->lineEdit->setText(ui->lineEdit->text() + "3");
}

void MainWindow::on_cztery_clicked()
{
    if (wynikObliczony) {
        ui->lineEdit->clear();
        wynikObliczony = false;
    }
    ui->lineEdit->setText(ui->lineEdit->text() + "4");
}

void MainWindow::on_piec_clicked()
{
    if (wynikObliczony) {
        ui->lineEdit->clear();
        wynikObliczony = false;
    }
    ui->lineEdit->setText(ui->lineEdit->text() + "5");
}

void MainWindow::on_szesc_clicked()
{
    if (wynikObliczony) {
        ui->lineEdit->clear();
        wynikObliczony = false;
    }
    ui->lineEdit->setText(ui->lineEdit->text() + "6");
}

void MainWindow::on_siedem_clicked()
{
    if (wynikObliczony) {
        ui->lineEdit->clear();
        wynikObliczony = false;
    }
    ui->lineEdit->setText(ui->lineEdit->text() + "7");
}

void MainWindow::on_osiem_clicked()
{
    if (wynikObliczony) {
        ui->lineEdit->clear();
        wynikObliczony = false;
    }
    ui->lineEdit->setText(ui->lineEdit->text() + "8");
}

void MainWindow::on_dziewiec_clicked()
{
    if (wynikObliczony) {
        ui->lineEdit->clear();
        wynikObliczony = false;
    }
    ui->lineEdit->setText(ui->lineEdit->text() + "9");
}

void MainWindow::on_zero_clicked()
{
    if (wynikObliczony) {
        ui->lineEdit->clear();
        wynikObliczony = false;
    }
    ui->lineEdit->setText(ui->lineEdit->text() + "0");
}

void MainWindow::on_zero_zero_clicked()
{
    if (wynikObliczony) {
        ui->lineEdit->clear();
        wynikObliczony = false;
    }
    ui->lineEdit->setText(ui->lineEdit->text() + "00");
}

void MainWindow::on_przecinek_clicked()
{
    QString currentText = ui->lineEdit->text();

    if (wynikObliczony) {
        ui->lineEdit->clear();
        wynikObliczony = false;
    }

    if (currentText.isEmpty()) {
        return;
    }

    QStringList operators = {" + ", " - ", " x ", " : ", " % "};
    int lastOpIndex = -1;

    for (const QString &op : operators) { //szukanie przercinka
        int index = currentText.lastIndexOf(op);
        if (index > lastOpIndex) {
            lastOpIndex = index;
        }
    }

    QString lastNumber = (lastOpIndex >= 0)
                             ? currentText.mid(lastOpIndex + 3)  // operatory mają 3 znaki ze spacja
                             : currentText;

    if (lastNumber.contains(".")) {
        return;
    }

    ui->lineEdit->setText(currentText + ".");
}


void MainWindow::on_rowna_clicked()
{
    QString input = ui->lineEdit->text();
    QStringList parts;
    double a = 0, b = 0;
    double result = 0;

    if (input.contains("=")) {
        return;
    }

    if (input.contains(" + ")) {
        parts = input.split(" + "); //dzielenie na dwie czesci
        if (parts.size() == 2) { //(liczba + liczba)
            a = parts[0].toDouble(); //konwersja na liczbe
            b = parts[1].toDouble();
            result = kalk.add(a, b);
        }
    }
    else if (input.contains(" - ")) {
        parts = input.split(" - ");
        if (parts.size() == 2) {
            a = parts[0].toDouble();
            b = parts[1].toDouble();
            result = kalk.sub(a, b);
        }
    }
    else if (input.contains(" x ")) {
        parts = input.split(" x ");
        if (parts.size() == 2) {
            a = parts[0].toDouble();
            b = parts[1].toDouble();
            result = kalk.mul(a, b);
        }
    }
    else if (input.contains(" : ")) {
        parts = input.split(" : ");
        if (parts.size() == 2) {
            a = parts[0].toDouble();
            b = parts[1].toDouble();

            if (b == 0) {
                QMessageBox::warning(this, "Błąd", "Dzielenie przez zero!");
                return;
            }

            result = kalk.div(a, b);
        }
    }
    else if (input.contains(" % ")) {
        parts = input.split(" % ");
        if (parts.size() == 2) {
            a = parts[0].toDouble();
            b = parts[1].toDouble();

            if (b == 0) {
                QMessageBox::warning(this, "Błąd", "Modulo przez zero!");
                return;
            }

            result = kalk.mod(a, b);
        }
    }
    else {
        QMessageBox::information(this, "Informacja", "Nieznana operacja.");
        return;
    }

    ui->lineEdit->setText(input + " = " + QString::number(result));
    wynikObliczony = true;

}


void MainWindow::on_plus_clicked()
{
    QString text = ui->lineEdit->text();
    QStringList operators = {" + ", " - ", " x ", " : ", " % "};
    for (const QString &op : operators) {
        if (text.contains(op)) return;
    }
    ui->lineEdit->setText(text + " + ");
}

void MainWindow::on_minus_clicked()
{
    QString text = ui->lineEdit->text();
    QStringList operators = {" + ", " - ", " x ", " : ", " % "};
    for (const QString &op : operators) {
        if (text.contains(op)) return;
    }
    ui->lineEdit->setText(text + " - ");
}

void MainWindow::on_razy_clicked()
{
    QString text = ui->lineEdit->text();
    QStringList operators = {" + ", " - ", " x ", " : ", " % "};
    for (const QString &op : operators) {
        if (text.contains(op)) return;
    }
    ui->lineEdit->setText(text + " x ");
}

void MainWindow::on_podzielic_clicked()
{
    QString text = ui->lineEdit->text();
    QStringList operators = {" + ", " - ", " x ", " : ", " % "};
    for (const QString &op : operators) {
        if (text.contains(op)) return;
    }
    ui->lineEdit->setText(text + " : ");
}

void MainWindow::on_modulo_clicked()
{
    QString text = ui->lineEdit->text();
    QStringList operators = {" + ", " - ", " x ", " : ", " % "};
    for (const QString &op : operators) {
        if (text.contains(op)) return;
    }
    ui->lineEdit->setText(text + " % ");
}

void MainWindow::on_reset_clicked()
{
    ui->lineEdit->clear();
    firstNumber = 0;
    kalk.erase();
}

void MainWindow::on_setMem_clicked()
{
    bool ok;
    QString text = ui->lineEdit->text();
    if (text.isEmpty()) {
        QMessageBox::warning(this, "Błąd", "Brak wartości do zapamiętania.");
        return;
    }

    double value = text.toDouble(&ok);
    if (ok) {
        kalk.setMem(kalk.getMem() + value);
    } else {
        QMessageBox::warning(this, "Błąd", "Nieprawidłowa wartość do zapamiętania.");
    }
}



void MainWindow::on_getMem_clicked()
{
    if (kalk.isMemUsed()) {
        ui->lineEdit->setText(QString::number(kalk.getMem()));
    } else {
        QMessageBox::information(this, "Informacja", "Pamięć jest pusta.");
    }
}


void MainWindow::on_erase_clicked()
{
    kalk.erase();
}


void MainWindow::on_binarny_clicked()
{
    bool ok;
    int number = ui->lineEdit->text().toInt(&ok); // tekstu na liczbę
    if (ok) {
        QString binary = QString::number(number, 2);  //  liczba na system binarny
        ui->lineEdit->setText(binary);
    } else {
        ui->lineEdit->setText("Błąd!");
    }
}

void MainWindow::on_osemkowy_clicked()
{
    bool ok;
    int number = ui->lineEdit->text().toInt(&ok);
    if (ok) {
        QString octal = QString::number(number, 8);
        ui->lineEdit->setText(octal);
    } else {
        ui->lineEdit->setText("Błąd!");
    }
}

void MainWindow::on_szesnastkowy_clicked()
{
    bool ok;
    int number = ui->lineEdit->text().toInt(&ok);
    if (ok) {
        QString hex = QString::number(number, 16).toUpper();
        ui->lineEdit->setText(hex);
    } else {
        ui->lineEdit->setText("Błąd!");
    }
}

void MainWindow::on_backspace_clicked()
{
    QString currentText = ui->lineEdit->text();

    if (currentText.endsWith(" + ") || currentText.endsWith(" - ") ||
        currentText.endsWith(" x ") || currentText.endsWith(" : ") ||
        currentText.endsWith(" % ")) {
        currentText.chop(3);
    } else if (!currentText.isEmpty()) {
        currentText.chop(1);
    }

    ui->lineEdit->setText(currentText);
}

void MainWindow::on_wyjscie_clicked()
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Wyjście", "Czy na pewno chcesz zakończyć działanie kalkulatora?",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        QApplication::quit();
    }
}
